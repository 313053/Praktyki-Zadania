require "test_helper"

class SamochodsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @samochod = samochods(:one)
  end

  test "should get index" do
    get samochods_url
    assert_response :success
  end

  test "should get new" do
    get new_samochod_url
    assert_response :success
  end

  test "should create samochod" do
    assert_difference("Samochod.count") do
      post samochods_url, params: { samochod: { marka: @samochod.marka, model_id: @samochod.model_id, model_nazwa: @samochod.model_nazwa } }
    end

    assert_redirected_to samochod_url(Samochod.last)
  end

  test "should show samochod" do
    get samochod_url(@samochod)
    assert_response :success
  end

  test "should get edit" do
    get edit_samochod_url(@samochod)
    assert_response :success
  end

  test "should update samochod" do
    patch samochod_url(@samochod), params: { samochod: { marka: @samochod.marka, model_id: @samochod.model_id, model_nazwa: @samochod.model_nazwa } }
    assert_redirected_to samochod_url(@samochod)
  end

  test "should destroy samochod" do
    assert_difference("Samochod.count", -1) do
      delete samochod_url(@samochod)
    end

    assert_redirected_to samochods_url
  end
end
