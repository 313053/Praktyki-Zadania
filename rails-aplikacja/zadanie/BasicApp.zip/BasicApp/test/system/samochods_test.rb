require "application_system_test_case"

class SamochodsTest < ApplicationSystemTestCase
  setup do
    @samochod = samochods(:one)
  end

  test "visiting the index" do
    visit samochods_url
    assert_selector "h1", text: "Samochods"
  end

  test "should create samochod" do
    visit samochods_url
    click_on "New samochod"

    fill_in "Marka", with: @samochod.marka
    fill_in "Model", with: @samochod.model_id
    fill_in "Model nazwa", with: @samochod.model_nazwa
    click_on "Create Samochod"

    assert_text "Samochod was successfully created"
    click_on "Back"
  end

  test "should update Samochod" do
    visit samochod_url(@samochod)
    click_on "Edit this samochod", match: :first

    fill_in "Marka", with: @samochod.marka
    fill_in "Model", with: @samochod.model_id
    fill_in "Model nazwa", with: @samochod.model_nazwa
    click_on "Update Samochod"

    assert_text "Samochod was successfully updated"
    click_on "Back"
  end

  test "should destroy Samochod" do
    visit samochod_url(@samochod)
    click_on "Destroy this samochod", match: :first

    assert_text "Samochod was successfully destroyed"
  end
end
