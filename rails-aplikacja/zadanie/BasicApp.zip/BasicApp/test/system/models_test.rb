require "application_system_test_case"

class ModelsTest < ApplicationSystemTestCase
  setup do
    @model = models(:one)
  end

  test "visiting the index" do
    visit models_url
    assert_selector "h1", text: "Models"
  end

  test "should create model" do
    visit models_url
    click_on "New model"

    fill_in "Dlugosc", with: @model.dlugosc
    fill_in "Liczba drzwi", with: @model.liczba_drzwi
    fill_in "Marka", with: @model.marka_id
    fill_in "Moc silnika", with: @model.moc_silnika
    fill_in "Nazwa", with: @model.nazwa
    fill_in "Pelna nazwa", with: @model.pelna_nazwa
    fill_in "Predkosc maksymalna", with: @model.predkosc_maksymalna
    fill_in "Produkowany", with: @model.produkowany
    fill_in "Rodzaj skrzyni", with: @model.rodzaj_skrzyni
    fill_in "Rozstaw kol przod", with: @model.rozstaw_kol_przod
    fill_in "Rozstaw kol tyl", with: @model.rozstaw_kol_tyl
    fill_in "Szerokosc", with: @model.szerokosc
    fill_in "Typ silnika", with: @model.typ_silnika
    fill_in "Wysokosc", with: @model.wysokosc
    click_on "Create Model"

    assert_text "Model was successfully created"
    click_on "Back"
  end

  test "should update Model" do
    visit model_url(@model)
    click_on "Edit this model", match: :first

    fill_in "Dlugosc", with: @model.dlugosc
    fill_in "Liczba drzwi", with: @model.liczba_drzwi
    fill_in "Marka", with: @model.marka_id
    fill_in "Moc silnika", with: @model.moc_silnika
    fill_in "Nazwa", with: @model.nazwa
    fill_in "Pelna nazwa", with: @model.pelna_nazwa
    fill_in "Predkosc maksymalna", with: @model.predkosc_maksymalna
    fill_in "Produkowany", with: @model.produkowany
    fill_in "Rodzaj skrzyni", with: @model.rodzaj_skrzyni
    fill_in "Rozstaw kol przod", with: @model.rozstaw_kol_przod
    fill_in "Rozstaw kol tyl", with: @model.rozstaw_kol_tyl
    fill_in "Szerokosc", with: @model.szerokosc
    fill_in "Typ silnika", with: @model.typ_silnika
    fill_in "Wysokosc", with: @model.wysokosc
    click_on "Update Model"

    assert_text "Model was successfully updated"
    click_on "Back"
  end

  test "should destroy Model" do
    visit model_url(@model)
    click_on "Destroy this model", match: :first

    assert_text "Model was successfully destroyed"
  end
end
