require "test_helper"

class SamochodTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
