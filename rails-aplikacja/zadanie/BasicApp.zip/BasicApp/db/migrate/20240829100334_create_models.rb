class CreateModels < ActiveRecord::Migration[7.2]
  def change
    create_table :models do |t|
      t.string :nazwa
      t.string :pelna_nazwa
      t.string :typ_silnika
      t.string :moc_silnika
      t.string :produkowany
      t.string :rodzaj_skrzyni
      t.string :dlugosc
      t.string :szerokosc
      t.string :wysokosc
      t.string :rozstaw_kol_przod
      t.string :rozstaw_kol_tyl
      t.integer :liczba_drzwi
      t.string :predkosc_maksymalna
      t.references :marka, null: false, foreign_key: true

      t.timestamps
    end
  end
end
