class AddAdmin < ActiveRecord::Migration[7.2]
  def change
    User.create! do |user|
      user.email = 'admin@admin.com'
      user.password = '123456'
      user.admin = true
    end
  end
end
