class CreateMarkas < ActiveRecord::Migration[7.2]
  def change
    create_table :markas do |t|
      t.string :nazwa

      t.timestamps
    end
  end
end
