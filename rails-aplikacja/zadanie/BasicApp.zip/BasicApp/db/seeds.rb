# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end
require 'csv'
require 'tty-progressbar'

i = 0
progress_bar = TTY::ProgressBar.new(":current / :total", total: 29336)
marki = []

CSV.foreach('db/sample_data/dane_aut.csv', headers: true, encoding:'UTF-8') do |row|
  i += 1

  begin

    if(marki.include?(row['Marka']))
      marka = Marka.find_by(nazwa: row['Marka'])
    else
      marka = Marka.create(id:i, nazwa: row['Marka'])
      marki << row['Marka'] 
    end

    marka.models.create(
                id: i,
                nazwa: row['Model'],
                pelna_nazwa: row['Pełna nazwa'],
                typ_silnika: row['Typ silnika'],
                moc_silnika: row['Moc silnika'],
                produkowany: row['Produkowany'],
                rodzaj_skrzyni: row['Rodzaj skrzyni'],
                dlugosc: row['Długość'].gsub("\u00A0", " "),
                szerokosc: row['Szerokość'].gsub("\u00A0", " "),
                wysokosc: row['Wysokość'].gsub("\u00A0", " "),
                rozstaw_kol_przod: row['Rozstaw kół - przód'].gsub("\u00A0", " "),
                rozstaw_kol_tyl: row['Rozstaw kół - tył'].gsub("\u00A0", " "),
                liczba_drzwi: row['Liczba drzwi'],
                predkosc_maksymalna: row['Prędkość maksymalna'].gsub("\u00A0", " "))
  rescue ActiveRecord::RecordInvalid => e
    puts "Failed to create record: #{e.message}"
  end    
  progress_bar.advance
end

puts ''