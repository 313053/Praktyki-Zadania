class Model < ApplicationRecord
  belongs_to :marka
end
