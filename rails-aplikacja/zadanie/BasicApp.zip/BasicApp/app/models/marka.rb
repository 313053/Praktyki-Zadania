class Marka < ApplicationRecord
  has_many :models
end
