module ApplicationHelper
  def navbar_link(name, path)
    class_name = request.path.start_with?(path) ? 'nav-item nav-link active' : 'nav-item nav-link'
    link_to name, path, class: class_name
  end
end
