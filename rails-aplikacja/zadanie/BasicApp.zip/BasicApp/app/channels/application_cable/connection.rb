module ApplicationCable
  class Connection < ActionCable::Connection::Base
  end
end
